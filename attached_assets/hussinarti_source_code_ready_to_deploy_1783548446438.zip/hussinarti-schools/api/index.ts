import "dotenv/config";
import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "../server/_core/oauth";
import { registerStorageProxy } from "../server/_core/storageProxy";
import { appRouter } from "../server/routers";
import { createContext } from "../server/_core/context";

// Vercel serverless entry point.
// Unlike server/_core/index.ts (used for local dev / traditional hosting,
// which calls `server.listen(...)`), this file exports the Express app
// directly so Vercel's Node runtime can invoke it per-request. Static
// assets (the built client) are served separately by Vercel itself,
// configured via vercel.json — this handler only serves /api/*.
const app = express();

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

registerStorageProxy(app);
registerOAuthRoutes(app);

app.use(
  "/api/trpc",
  createExpressMiddleware({
    router: appRouter,
    createContext,
  })
);

export default app;

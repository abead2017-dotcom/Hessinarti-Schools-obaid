-- Initial schema for hussinarti-schools (PostgreSQL / Supabase)
-- Generated to match drizzle/schema.ts after the MySQL -> PostgreSQL migration.

CREATE TYPE "user_role" AS ENUM ('user', 'admin', 'student', 'teacher');
CREATE TYPE "notification_recipient_type" AS ENUM ('all', 'students', 'specific');

CREATE TABLE "users" (
  "id" serial PRIMARY KEY,
  "openId" varchar(64) NOT NULL UNIQUE,
  "name" text,
  "email" varchar(320),
  "loginMethod" varchar(64),
  "role" user_role NOT NULL DEFAULT 'user',
  "studentId" varchar(64),
  "createdAt" timestamp NOT NULL DEFAULT now(),
  "updatedAt" timestamp NOT NULL DEFAULT now(),
  "lastSignedIn" timestamp NOT NULL DEFAULT now()
);

CREATE TABLE "results" (
  "id" serial PRIMARY KEY,
  "studentId" integer NOT NULL,
  "subject" varchar(255) NOT NULL,
  "grade" varchar(10) NOT NULL,
  "score" integer,
  "semester" varchar(50) NOT NULL,
  "academicYear" varchar(50) NOT NULL,
  "createdAt" timestamp NOT NULL DEFAULT now(),
  "updatedAt" timestamp NOT NULL DEFAULT now()
);

CREATE TABLE "books" (
  "id" serial PRIMARY KEY,
  "title" varchar(255) NOT NULL,
  "subject" varchar(255) NOT NULL,
  "grade" varchar(50) NOT NULL,
  "fileUrl" text NOT NULL,
  "fileKey" varchar(255) NOT NULL,
  "uploadedBy" integer NOT NULL,
  "description" text,
  "createdAt" timestamp NOT NULL DEFAULT now(),
  "updatedAt" timestamp NOT NULL DEFAULT now()
);

CREATE TABLE "calendarEvents" (
  "id" serial PRIMARY KEY,
  "title" varchar(255) NOT NULL,
  "description" text,
  "startDate" timestamp NOT NULL,
  "endDate" timestamp,
  "eventType" varchar(50) NOT NULL,
  "createdBy" integer NOT NULL,
  "createdAt" timestamp NOT NULL DEFAULT now(),
  "updatedAt" timestamp NOT NULL DEFAULT now()
);

CREATE TABLE "notifications" (
  "id" serial PRIMARY KEY,
  "title" varchar(255) NOT NULL,
  "message" text NOT NULL,
  "recipientType" notification_recipient_type NOT NULL,
  "recipientIds" text,
  "sentBy" integer NOT NULL,
  "isRead" integer NOT NULL DEFAULT 0,
  "createdAt" timestamp NOT NULL DEFAULT now()
);

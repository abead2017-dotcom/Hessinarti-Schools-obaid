import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BookOpen, Users, Settings } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function RoleSelection() {
  const [, setLocation] = useLocation();
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const updateRole = trpc.auth.updateUserRole.useMutation({
    onSuccess: (data) => {
      if (data.role === "student") {
        setLocation("/dashboard/student");
      } else if (data.role === "teacher") {
        setLocation("/dashboard/teacher");
      } else if (data.role === "admin") {
        setLocation("/dashboard/admin");
      }
    },
  });

  const handleRoleSelect = async (role: string) => {
    setSelectedRole(role);
    setIsLoading(true);
    updateRole.mutate({ role: role as "student" | "teacher" | "admin" });
  };

  const roles = [
    {
      id: "student",
      name: "طالب",
      description: "عرض النتائج الدراسية وتحميل الكتب والاطلاع على التقويم",
      icon: Users,
      color: "bg-blue-100 text-blue-600",
    },
    {
      id: "teacher",
      name: "معلم",
      description: "رفع الكتب التعليمية بصيغة PDF ومتابعة الطلاب",
      icon: BookOpen,
      color: "bg-green-100 text-green-600",
    },
    {
      id: "admin",
      name: "مدير",
      description: "إدارة النتائج والكتب والتقويم والإشعارات",
      icon: Settings,
      color: "bg-purple-100 text-purple-600",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">اختر دورك في المنصة</h1>
            <p className="text-xl text-gray-600">
              اختر الدور الذي ينطبق عليك للوصول إلى لوحة التحكم الخاصة بك
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {roles.map((role) => (
              <Card
                key={role.id}
                className={`p-8 text-center cursor-pointer transition-all hover:shadow-xl ${
                  selectedRole === role.id ? "ring-2 ring-blue-600" : ""
                }`}
                onClick={() => !isLoading && handleRoleSelect(role.id)}
              >
                <div className={`${role.color} p-6 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6`}>
                  <role.icon className="w-10 h-10" />
                </div>
                <h2 className="text-2xl font-bold text-gray-800 mb-3">{role.name}</h2>
                <p className="text-gray-600 mb-6">{role.description}</p>
                <Button
                  onClick={() => !isLoading && handleRoleSelect(role.id)}
                  disabled={isLoading}
                  className={`w-full py-2 rounded-lg font-semibold transition-all ${
                    selectedRole === role.id
                      ? "bg-blue-600 hover:bg-blue-700 text-white"
                      : "bg-gray-200 hover:bg-gray-300 text-gray-800"
                  }`}
                >
                  {isLoading && selectedRole === role.id ? "جاري التحميل..." : "اختر هذا الدور"}
                </Button>
              </Card>
            ))}
          </div>

          <div className="mt-12 p-6 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="text-lg font-bold text-gray-800 mb-3">معلومات مهمة:</h3>
            <ul className="text-right text-gray-700 space-y-2">
              <li>✓ يمكنك تغيير دورك لاحقاً من إعدادات الحساب</li>
              <li>✓ كل دور له صلاحيات مختلفة ومحددة</li>
              <li>✓ تأكد من اختيار الدور الصحيح قبل المتابعة</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

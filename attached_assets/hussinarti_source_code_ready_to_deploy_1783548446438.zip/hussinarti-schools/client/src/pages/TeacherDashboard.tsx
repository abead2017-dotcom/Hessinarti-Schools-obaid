import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { BookOpen, Upload, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";

export default function TeacherDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showUploadForm, setShowUploadForm] = useState(false);

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const { data: books } = trpc.books.getBooks.useQuery();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-green-600 to-green-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">لوحة تحكم المعلم</h1>
              <p className="text-green-100 mt-1">مرحباً {user?.name}</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="bg-green-500 px-3 py-1 rounded-full text-sm">معلم</span>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="text-white border-white hover:bg-green-700"
              >
                <LogOut className="w-4 h-4 ml-2" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-end gap-8 py-4">
            <Link href="/books">
              <a className="text-gray-700 hover:text-green-600 font-medium transition">الكتب</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <Card className="p-6 text-center">
            <div className="bg-green-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-gray-600 text-sm">الكتب المرفوعة</p>
            <p className="text-3xl font-bold text-gray-800">
              {books?.filter((b: any) => b.uploadedBy === user?.id).length || 0}
            </p>
          </Card>

          <Card className="p-6 text-center">
            <div className="bg-blue-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <Upload className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-gray-600 text-sm">إجمالي الكتب</p>
            <p className="text-3xl font-bold text-gray-800">{books?.length || 0}</p>
          </Card>
        </div>

        {/* Upload Section */}
        <Card className="p-8 mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">رفع كتاب جديد</h2>
            <Button
              onClick={() => setShowUploadForm(!showUploadForm)}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Upload className="w-4 h-4 ml-2" />
              رفع كتاب
            </Button>
          </div>

          {showUploadForm && <UploadBookForm onSuccess={() => setShowUploadForm(false)} />}
        </Card>

        {/* My Books */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">الكتب التي رفعتها</h2>
          {books && books.filter((b: any) => b.uploadedBy === user?.id).length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {books
                .filter((b: any) => b.uploadedBy === user?.id)
                .map((book: any) => (
                  <Card key={book.id} className="p-4 hover:shadow-lg transition-shadow">
                    <div className="bg-green-100 p-3 rounded-lg mb-3">
                      <BookOpen className="w-6 h-6 text-green-600" />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">{book.title}</h3>
                    <p className="text-sm text-gray-600 mb-1">المادة: {book.subject}</p>
                    <p className="text-sm text-gray-600 mb-3">الصف: {book.grade}</p>
                    {book.description && (
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">{book.description}</p>
                    )}
                    <p className="text-xs text-gray-500">
                      {new Date(book.createdAt).toLocaleDateString("ar-SA")}
                    </p>
                  </Card>
                ))}
            </div>
          ) : (
            <p className="text-gray-600 text-center py-12">لم تقم برفع أي كتب حتى الآن</p>
          )}
        </Card>
      </main>
    </div>
  );
}

function UploadBookForm({ onSuccess }: any) {
  const [formData, setFormData] = useState({
    title: "",
    subject: "",
    grade: "",
    description: "",
  });
  const [file, setFile] = useState<File | null>(null);

  const uploadBook = trpc.books.uploadBook.useMutation({
    onSuccess: () => {
      setFormData({ title: "", subject: "", grade: "", description: "" });
      setFile(null);
      onSuccess();
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    const fileUrl = URL.createObjectURL(file);
    const fileKey = `books/${Date.now()}-${file.name}`;

    uploadBook.mutate({
      title: formData.title,
      subject: formData.subject,
      grade: formData.grade,
      fileUrl: fileUrl,
      fileKey: fileKey,
      description: formData.description,
    });
  };

  return (
    <div className="bg-green-50 p-6 rounded-lg border border-green-200">
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          placeholder="عنوان الكتاب"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />

        <select
          value={formData.subject}
          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
          required
        >
          <option value="">اختر المادة</option>
          <option value="اللغة العربية">اللغة العربية</option>
          <option value="الرياضيات">الرياضيات</option>
          <option value="العلوم">العلوم</option>
          <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
          <option value="الدراسات الاجتماعية">الدراسات الاجتماعية</option>
        </select>

        <select
          value={formData.grade}
          onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
          required
        >
          <option value="">اختر الصف</option>
          <option value="الصف الأول">الصف الأول</option>
          <option value="الصف الثاني">الصف الثاني</option>
          <option value="الصف الثالث">الصف الثالث</option>
          <option value="الصف الرابع">الصف الرابع</option>
          <option value="الصف الخامس">الصف الخامس</option>
          <option value="الصف السادس">الصف السادس</option>
        </select>

        <div className="md:col-span-2">
          <input
            type="file"
            accept=".pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
            required
          />
          <p className="text-sm text-gray-600 mt-1">ملفات PDF فقط</p>
        </div>

        <Input
          placeholder="الوصف (اختياري)"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="md:col-span-2"
        />

        <Button
          type="submit"
          disabled={uploadBook.isPending || !file}
          className="bg-green-600 hover:bg-green-700 text-white md:col-span-2"
        >
          {uploadBook.isPending ? "جاري الرفع..." : "رفع الكتاب"}
        </Button>
      </form>
    </div>
  );
}

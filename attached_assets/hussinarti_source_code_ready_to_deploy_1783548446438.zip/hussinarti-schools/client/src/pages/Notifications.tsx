import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Bell, Plus, LogOut } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Notifications() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showSendForm, setShowSendForm] = useState(false);

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const { data: notifications } = trpc.notifications.getNotifications.useQuery();

  const isAdmin = user?.role === "admin";

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-orange-600 to-orange-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">الإشعارات</h1>
              <p className="text-orange-100 mt-1">إدارة الإشعارات والرسالل المهمة</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="text-white border-white hover:bg-orange-700"
            >
              <LogOut className="w-4 h-4 ml-2" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-end gap-8 py-4">
            <Link href={user?.role === "student" ? "/dashboard/student" : user?.role === "teacher" ? "/dashboard/teacher" : "/dashboard/admin"}>
              <a className="text-gray-700 hover:text-orange-600 font-medium transition">لوحة التحكم</a>
            </Link>
            <Link href="/results">
              <a className="text-gray-700 hover:text-orange-600 font-medium transition">النتائج</a>
            </Link>
            <Link href="/books">
              <a className="text-gray-700 hover:text-orange-600 font-medium transition">الكتب</a>
            </Link>
            <Link href="/calendar">
              <a className="text-gray-700 hover:text-orange-600 font-medium transition">التقويم</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
      {/* Send Notification Button */}
      {isAdmin && (
        <div className="mb-8">
          <Button
            onClick={() => setShowSendForm(!showSendForm)}
            className="bg-orange-600 hover:bg-orange-700 text-white"
          >
            <Plus className="w-4 h-4 ml-2" />
            إرسال إشعار جديد
          </Button>
        </div>
      )}

      {/* Send Notification Form */}
      {showSendForm && isAdmin && (
        <Card className="p-6 mb-8">
          <SendNotificationForm onSuccess={() => setShowSendForm(false)} />
        </Card>
      )}

      {/* Notifications List */}
      <Card className="p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">الإشعارات</h2>
        {notifications && notifications.length > 0 ? (
          <div className="space-y-4">
            {notifications.map((notification: any) => (
            <div key={notification.id} className="p-6 bg-gradient-to-l from-orange-50 to-yellow-50 rounded-lg border-r-4 border-orange-600">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-800 mb-2">{notification.title}</h3>
                  <p className="text-gray-700 mb-3">{notification.message}</p>
                  <div className="flex gap-4 text-sm text-gray-600">
                    <div>
                      <span className="font-semibold">الموجهة إلى:</span> {notification.targetAudience || "جميع الطلاب"}
                    </div>
                    <div>
                      <span className="font-semibold">التاريخ:</span> {new Date(notification.createdAt).toLocaleDateString("ar-SA")}
                    </div>
                  </div>
                </div>
                <div className="bg-orange-100 p-3 rounded-lg ml-4">
                  <Bell className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Bell className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">لا توجد إشعارات</p>
          </div>
        )}
      </Card>
      </main>
    </div>
  );
}

function SendNotificationForm({ onSuccess }: any) {
  const [formData, setFormData] = useState({
    title: "",
    message: "",
    recipientType: "all",
    recipientIds: "",
  });

  const sendNotification = trpc.notifications.sendNotification.useMutation({
    onSuccess: () => {
      setFormData({
        title: "",
        message: "",
        recipientType: "all",
        recipientIds: "",
      });
      onSuccess();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendNotification.mutate({
      title: formData.title,
      message: formData.message,
      recipientType: formData.recipientType as "all" | "students" | "specific",
      recipientIds: formData.recipientIds || undefined,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-xl font-bold text-gray-800 mb-4">إرسال إشعار جديد</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          placeholder="عنوان الإشعار"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />

        <select
          value={formData.recipientType}
          onChange={(e) => setFormData({ ...formData, recipientType: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-600"
        >
          <option value="all">جميع الطلاب</option>
          <option value="students">طلاب الصف الأول</option>
          <option value="specific">طلاب محددين</option>
        </select>

        <textarea
          placeholder="نص الإشعار"
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          required
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-600 md:col-span-2"
          rows={4}
        />
      </div>

      <Button
        type="submit"
        disabled={sendNotification.isPending}
        className="w-full bg-orange-600 hover:bg-orange-700 text-white"
      >
        {sendNotification.isPending ? "جاري الإرسال..." : "إرسال الإشعار"}
      </Button>
    </form>
  );
}

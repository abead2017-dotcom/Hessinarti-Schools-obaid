import React from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { BookOpen, Calendar, FileText, Bell, Users, LogOut } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = async () => {
    setIsLoggingOut(true);
    await logout();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-l from-blue-600 to-blue-700">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-lg">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated && user) {
    // إذا لم يكن للمستخدم دور محدد، اعرض صفحة اختيار الدور
    if (user.role === 'user') {
      return <RoleSelectionRedirect />;
    }
    return <DashboardPage user={user} onLogout={handleLogout} isLoggingOut={isLoggingOut} />;
  }

  return <LandingPage />;
}

function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-gradient-to-l from-blue-600 to-blue-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BookOpen className="w-8 h-8" />
              <h1 className="text-3xl font-bold">مدارس حسينارتي</h1>
            </div>
            <a href={getLoginUrl()} className="text-white hover:bg-blue-800 px-4 py-2 rounded-lg transition">
              دخول
            </a>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-l from-blue-50 to-blue-100 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">منصة تعليمية متكاملة</h2>
            <p className="text-xl text-gray-600 mb-8">
              منصة حديثة توفر تجربة تعليمية شاملة للطلاب والمعلمين والإدارة
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg">
                ابدأ الآن
              </Button>
            </a>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">المميزات الرئيسية</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <feature.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">الأدوار المختلفة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {roles.map((role, index) => (
              <Card key={index} className="p-8 text-center hover:shadow-lg transition-shadow">
                <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <role.icon className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">{role.name}</h3>
                <ul className="text-right text-gray-600 space-y-2">
                  {role.permissions.map((perm, idx) => (
                    <li key={idx} className="flex items-center justify-end gap-2">
                      <span>{perm}</span>
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 مدارس حسينارتي. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}

function RoleSelectionRedirect() {
  const [, setLocation] = useLocation();
  React.useEffect(() => {
    setLocation('/role-selection');
  }, [setLocation]);
  return null;
}

function DashboardPage({ user, onLogout, isLoggingOut }: any) {
  const roleLabelMap: Record<string, string> = {
    admin: 'مدير',
    student: 'طالب',
    teacher: 'معلم',
    user: 'مستخدم',
  };
  const roleLabel = roleLabelMap[user.role] || user.role;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-l from-blue-600 to-blue-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">مدارس حسينارتي</h1>
              <p className="text-blue-100 mt-1">مرحباً {user.name} - {roleLabel}</p>
            </div>
            <Button
              onClick={onLogout}
              disabled={isLoggingOut}
              variant="outline"
              className="text-white border-white hover:bg-blue-700"
            >
              <LogOut className="w-4 h-4 ml-2" />
              {isLoggingOut ? 'جاري التسجيل...' : 'تسجيل الخروج'}
            </Button>
          </div>
        </div>
      </header>

      <nav className="bg-white shadow">
        <div className="container mx-auto px-4">
          <div className="flex gap-8 overflow-x-auto">
            {getNavigationItems(user.role).map((item, index) => (
              <Link key={index} href={item.href}>
                <a className="flex items-center gap-2 px-4 py-4 border-b-2 border-transparent hover:border-blue-600 transition text-gray-700 hover:text-blue-600">
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </a>
              </Link>
            ))}
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {getDashboardCards(user.role).map((card, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-600 text-sm">{card.label}</p>
                  <p className="text-3xl font-bold text-gray-800 mt-2">{card.value}</p>
                </div>
                <div className="bg-blue-100 p-3 rounded-lg">
                  <card.icon className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Card className="p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">إجراءات سريعة</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {getQuickActions(user.role).map((action, index) => (
              <Link key={index} href={action.href}>
                <a>
                  <Button variant="outline" className="w-full justify-start">
                    <action.icon className="w-4 h-4 ml-2" />
                    {action.label}
                  </Button>
                </a>
              </Link>
            ))}
          </div>
        </Card>
      </main>
    </div>
  );
}

const features = [
  {
    icon: FileText,
    title: 'النتائج الدراسية',
    description: 'عرض وإدارة النتائج الدراسية للطلاب بسهولة',
  },
  {
    icon: BookOpen,
    title: 'الكتب التعليمية',
    description: 'مكتبة شاملة من الكتب والمراجع التعليمية',
  },
  {
    icon: Calendar,
    title: 'التقويم الدراسي',
    description: 'متابعة الفعاليات والمواعيد المهمة',
  },
  {
    icon: Bell,
    title: 'الإشعارات',
    description: 'تلقي إشعارات فورية بأهم الأخبار',
  },
  {
    icon: Users,
    title: 'إدارة المستخدمين',
    description: 'إدارة حسابات الطلاب والمعلمين',
  },
  {
    icon: BookOpen,
    title: 'المحتوى التعليمي',
    description: 'محتوى تعليمي غني ومتنوع',
  },
];

const roles = [
  {
    name: 'الطالب',
    icon: Users,
    permissions: [
      'عرض النتائج الدراسية',
      'تحميل الكتب التعليمية',
      'الاطلاع على التقويم الدراسي',
      'استقبال الإشعارات',
    ],
  },
  {
    name: 'المعلم',
    icon: BookOpen,
    permissions: [
      'رفع الكتب التعليمية (PDF)',
      'عرض الكتب المرفوعة',
      'الاطلاع على التقويم الدراسي',
      'استقبال الإشعارات',
    ],
  },
  {
    name: 'المدير',
    icon: Users,
    permissions: [
      'رفع النتائج الدراسية',
      'رفع الكتب التعليمية',
      'إدارة التقويم الدراسي',
      'إرسال الإشعارات',
    ],
  },
];

function getNavigationItems(role: string) {
  const baseItems = [
    { href: '/', label: 'الرئيسية', icon: BookOpen },
    { href: '/calendar', label: 'التقويم', icon: Calendar },
    { href: '/notifications', label: 'الإشعارات', icon: Bell },
  ];

  if (role === 'student') {
    return [
      ...baseItems,
      { href: '/results', label: 'نتائجي', icon: FileText },
      { href: '/books', label: 'الكتب', icon: BookOpen },
    ];
  }

  if (role === 'teacher') {
    return [
      ...baseItems,
      { href: '/books', label: 'الكتب', icon: BookOpen },
      { href: '/upload-book', label: 'رفع كتاب', icon: FileText },
    ];
  }

  if (role === 'admin') {
    return [
      ...baseItems,
      { href: '/results', label: 'النتائج', icon: FileText },
      { href: '/books', label: 'الكتب', icon: BookOpen },
      { href: '/upload-result', label: 'رفع نتائج', icon: FileText },
      { href: '/upload-book', label: 'رفع كتاب', icon: BookOpen },
      { href: '/manage-calendar', label: 'إدارة التقويم', icon: Calendar },
      { href: '/send-notification', label: 'إرسال إشعار', icon: Bell },
    ];
  }

  return baseItems;
}

function getDashboardCards(role: string) {
  if (role === 'student') {
    return [
      { label: 'النتائج', value: '5', icon: FileText },
      { label: 'الكتب المتاحة', value: '12', icon: BookOpen },
      { label: 'الأحداث القادمة', value: '3', icon: Calendar },
      { label: 'الإشعارات الجديدة', value: '2', icon: Bell },
    ];
  }

  if (role === 'teacher') {
    return [
      { label: 'الكتب المرفوعة', value: '8', icon: BookOpen },
      { label: 'الطلاب', value: '45', icon: Users },
      { label: 'الأحداث', value: '6', icon: Calendar },
      { label: 'الإشعارات', value: '3', icon: Bell },
    ];
  }

  if (role === 'admin') {
    return [
      { label: 'الطلاب', value: '250', icon: Users },
      { label: 'المعلمون', value: '25', icon: BookOpen },
      { label: 'النتائج المرفوعة', value: '180', icon: FileText },
      { label: 'الإشعارات المرسلة', value: '42', icon: Bell },
    ];
  }

  return [];
}

function getQuickActions(role: string) {
  if (role === 'student') {
    return [
      { label: 'عرض نتائجي', href: '/results', icon: FileText },
      { label: 'تحميل الكتب', href: '/books', icon: BookOpen },
      { label: 'الأحداث القادمة', href: '/calendar', icon: Calendar },
    ];
  }

  if (role === 'teacher') {
    return [
      { label: 'رفع كتاب جديد', href: '/upload-book', icon: BookOpen },
      { label: 'عرض الكتب', href: '/books', icon: FileText },
      { label: 'التقويم الدراسي', href: '/calendar', icon: Calendar },
    ];
  }

  if (role === 'admin') {
    return [
      { label: 'رفع النتائج', href: '/upload-result', icon: FileText },
      { label: 'رفع كتاب', href: '/upload-book', icon: BookOpen },
      { label: 'إدارة التقويم', href: '/manage-calendar', icon: Calendar },
      { label: 'إرسال إشعار', href: '/send-notification', icon: Bell },
      { label: 'إدارة المستخدمين', href: '/users', icon: Users },
      { label: 'عرض التقارير', href: '/reports', icon: FileText },
    ];
  }

  return [];
}

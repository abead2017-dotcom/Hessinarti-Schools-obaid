import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { BarChart3, BookOpen, Calendar, Bell, LogOut, Plus } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const { data: results } = trpc.results.getAllResults.useQuery();
  const { data: books } = trpc.books.getBooks.useQuery();
  const { data: events } = trpc.calendar.getEvents.useQuery();
  const { data: notifications } = trpc.notifications.getNotifications.useQuery();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-purple-600 to-purple-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">لوحة تحكم المدير</h1>
              <p className="text-purple-100 mt-1">مرحباً {user?.name}</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="bg-purple-500 px-3 py-1 rounded-full text-sm">مدير</span>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="text-white border-white hover:bg-purple-700"
              >
                <LogOut className="w-4 h-4 ml-2" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-end gap-8 py-4">
            <button
              onClick={() => setActiveTab("overview")}
              className={`font-medium transition ${
                activeTab === "overview" ? "text-purple-600 border-b-2 border-purple-600 pb-4" : "text-gray-700 hover:text-purple-600"
              }`}
            >
              نظرة عامة
            </button>
            <Link href="/results">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">النتائج</a>
            </Link>
            <Link href="/books">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">الكتب</a>
            </Link>
            <Link href="/calendar">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">التقويم</a>
            </Link>
            <Link href="/notifications">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">الإشعارات</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {activeTab === "overview" && (
          <>
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
              <Card className="p-6 text-center">
                <div className="bg-blue-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                </div>
                <p className="text-gray-600 text-sm">النتائج</p>
                <p className="text-3xl font-bold text-gray-800">{results?.length || 0}</p>
              </Card>

              <Card className="p-6 text-center">
                <div className="bg-green-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <BookOpen className="w-6 h-6 text-green-600" />
                </div>
                <p className="text-gray-600 text-sm">الكتب</p>
                <p className="text-3xl font-bold text-gray-800">{books?.length || 0}</p>
              </Card>

              <Card className="p-6 text-center">
                <div className="bg-purple-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
                <p className="text-gray-600 text-sm">الأحداث</p>
                <p className="text-3xl font-bold text-gray-800">{events?.length || 0}</p>
              </Card>

              <Card className="p-6 text-center">
                <div className="bg-red-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <Bell className="w-6 h-6 text-red-600" />
                </div>
                <p className="text-gray-600 text-sm">الإشعارات</p>
                <p className="text-3xl font-bold text-gray-800">{notifications?.length || 0}</p>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card className="p-8 mb-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">إجراءات سريعة</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Link href="/results">
                  <a className="block">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                      <Plus className="w-4 h-4 ml-2" />
                      رفع النتائج
                    </Button>
                  </a>
                </Link>
                <Link href="/books">
                  <a className="block">
                    <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                      <Plus className="w-4 h-4 ml-2" />
                      رفع الكتب
                    </Button>
                  </a>
                </Link>
                <Link href="/calendar">
                  <a className="block">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                      <Plus className="w-4 h-4 ml-2" />
                      إضافة حدث
                    </Button>
                  </a>
                </Link>
                <Link href="/notifications">
                  <a className="block">
                    <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                      <Plus className="w-4 h-4 ml-2" />
                      إرسال إشعار
                    </Button>
                  </a>
                </Link>
              </div>
            </Card>

            {/* Recent Data */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Recent Results */}
              <Card className="p-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">آخر النتائج المرفوعة</h2>
                {results && results.length > 0 ? (
                  <div className="space-y-3">
                    {results.slice(0, 5).map((result: any) => (
                      <div key={result.id} className="p-3 bg-gray-50 rounded-lg">
                        <p className="font-semibold text-gray-800">{result.subject}</p>
                        <p className="text-sm text-gray-600">الطالب: {result.studentId} | {result.semester}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600 text-center py-8">لا توجد نتائج</p>
                )}
              </Card>

              {/* Recent Books */}
              <Card className="p-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">آخر الكتب المرفوعة</h2>
                {books && books.length > 0 ? (
                  <div className="space-y-3">
                    {books.slice(0, 5).map((book: any) => (
                      <div key={book.id} className="p-3 bg-gray-50 rounded-lg">
                        <p className="font-semibold text-gray-800">{book.title}</p>
                        <p className="text-sm text-gray-600">{book.subject} - {book.grade}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600 text-center py-8">لا توجد كتب</p>
                )}
              </Card>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

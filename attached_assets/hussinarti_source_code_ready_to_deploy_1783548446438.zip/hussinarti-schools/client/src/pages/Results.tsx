import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { FileText, Plus, LogOut } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Results() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showAddForm, setShowAddForm] = useState(false);

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const { data: results } = trpc.results.getMyResults.useQuery(
    undefined,
    { enabled: user?.role === "student" }
  );

  const { data: allResults } = trpc.results.getAllResults.useQuery(
    undefined,
    { enabled: user?.role === "admin" }
  );

  if (!user || (user.role !== "student" && user.role !== "admin")) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-gradient-to-l from-blue-600 to-blue-700 text-white shadow-lg">
          <div className="container mx-auto px-4 py-6">
            <h1 className="text-2xl font-bold">النتائج الدراسية</h1>
          </div>
        </header>
        <div className="container mx-auto px-4 py-12">
          <Card className="p-8 text-center">
            <p className="text-gray-600">ليس لديك صلاحية للوصول إلى هذه الصفحة</p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-blue-600 to-blue-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">النتائج الدراسية</h1>
              <p className="text-blue-100 mt-1">
                {user.role === "student" ? "نتائجك الدراسية" : "إدارة النتائج"}
              </p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="text-white border-white hover:bg-blue-700"
            >
              <LogOut className="w-4 h-4 ml-2" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-end gap-8 py-4">
            <Link href={user.role === "student" ? "/dashboard/student" : "/dashboard/admin"}>
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">لوحة التحكم</a>
            </Link>
            <Link href="/books">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">الكتب</a>
            </Link>
            <Link href="/calendar">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">التقويم</a>
            </Link>
            <Link href="/notifications">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">الإشعارات</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {user.role === "student" && (
          <StudentResultsView results={results || []} />
        )}

        {user.role === "admin" && (
          <AdminResultsView allResults={allResults || []} />
        )}
      </main>
    </div>
  );
}

function StudentResultsView({ results }: any) {
  const [selectedSemester, setSelectedSemester] = useState("الفصل الأول");
  const [selectedYear, setSelectedYear] = useState("2024");

  const filteredResults = results.filter(
    (r: any) => r.semester === selectedSemester && r.academicYear === selectedYear
  );

  return (
    <div>
      {/* Filters */}
      <Card className="p-6 mb-8">
        <h2 className="text-xl font-bold text-gray-800 mb-4">تصفية النتائج</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="الفصل الأول">الفصل الأول</option>
            <option value="الفصل الثاني">الفصل الثاني</option>
          </select>

          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
          </select>
        </div>
      </Card>

      {/* Results Table */}
      <Card className="p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-6">النتائج</h2>
        {filteredResults.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-right">
              <thead>
                <tr className="bg-gray-100 border-b-2 border-gray-300">
                  <th className="px-4 py-3 font-semibold text-gray-800">المادة</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">الدرجة</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">الفصل</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">السنة الدراسية</th>
                </tr>
              </thead>
              <tbody>
                {filteredResults.map((result: any) => (
                  <tr key={result.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-4 py-3 text-gray-800">{result.subject}</td>
                    <td className="px-4 py-3">
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-semibold">
                        {result.score || result.grade}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{result.semester}</td>
                    <td className="px-4 py-3 text-gray-600">{result.academicYear}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">لا توجد نتائج متاحة</p>
          </div>
        )}
      </Card>
    </div>
  );
}

function AdminResultsView({ allResults }: any) {
  const [showAddForm, setShowAddForm] = useState(false);

  return (
    <div>
      {/* Add Result Button */}
      <div className="mb-8">
        <Button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Plus className="w-4 h-4 ml-2" />
          إضافة نتيجة جديدة
        </Button>
      </div>

      {/* Add Result Form */}
      {showAddForm && (
        <Card className="p-6 mb-8">
          <AddResultForm onSuccess={() => setShowAddForm(false)} />
        </Card>
      )}

      {/* Results Table */}
      <Card className="p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-6">جميع النتائج</h2>
        {allResults.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-right">
              <thead>
                <tr className="bg-gray-100 border-b-2 border-gray-300">
                  <th className="px-4 py-3 font-semibold text-gray-800">الطالب</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">المادة</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">الدرجة</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">الفصل</th>
                  <th className="px-4 py-3 font-semibold text-gray-800">السنة</th>
                </tr>
              </thead>
              <tbody>
                {allResults.map((result: any) => (
                  <tr key={result.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-4 py-3 text-gray-800">الطالب #{result.studentId}</td>
                    <td className="px-4 py-3 text-gray-800">{result.subject}</td>
                    <td className="px-4 py-3">
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-semibold">
                        {result.score || result.grade}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{result.semester}</td>
                    <td className="px-4 py-3 text-gray-600">{result.academicYear}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">لا توجد نتائج مسجلة</p>
          </div>
        )}
      </Card>
    </div>
  );
}

function AddResultForm({ onSuccess }: any) {
  const [formData, setFormData] = useState({
    studentId: "",
    subject: "",
    grade: "",
    score: "",
    semester: "الفصل الأول",
    academicYear: "2024",
  });

  const addResult = trpc.results.addResult.useMutation({
    onSuccess: () => {
      setFormData({
        studentId: "",
        subject: "",
        grade: "",
        score: "",
        semester: "الفصل الأول",
        academicYear: "2024",
      });
      onSuccess();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addResult.mutate({
      studentId: parseInt(formData.studentId),
      subject: formData.subject,
      grade: formData.grade,
      score: formData.score ? parseInt(formData.score) : undefined,
      semester: formData.semester,
      academicYear: formData.academicYear,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          placeholder="رقم الطالب"
          type="number"
          value={formData.studentId}
          onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
          required
        />

        <select
          value={formData.subject}
          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          required
        >
          <option value="">اختر المادة</option>
          <option value="اللغة العربية">اللغة العربية</option>
          <option value="الرياضيات">الرياضيات</option>
          <option value="العلوم">العلوم</option>
          <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
        </select>

        <Input
          placeholder="التقدير (أ، ب، ج...)"
          value={formData.grade}
          onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
          required
        />

        <Input
          placeholder="الدرجة (اختياري)"
          type="number"
          value={formData.score}
          onChange={(e) => setFormData({ ...formData, score: e.target.value })}
        />

        <select
          value={formData.semester}
          onChange={(e) => setFormData({ ...formData, semester: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
        >
          <option value="الفصل الأول">الفصل الأول</option>
          <option value="الفصل الثاني">الفصل الثاني</option>
        </select>

        <select
          value={formData.academicYear}
          onChange={(e) => setFormData({ ...formData, academicYear: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
        >
          <option value="2024">2024</option>
          <option value="2025">2025</option>
          <option value="2026">2026</option>
        </select>
      </div>

      <Button
        type="submit"
        disabled={addResult.isPending}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
      >
        {addResult.isPending ? "جاري الحفظ..." : "حفظ النتيجة"}
      </Button>
    </form>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { BookOpen, Download, Upload } from "lucide-react";
import { useState } from "react";

export default function Books() {
  const { user } = useAuth();
  const [selectedGrade, setSelectedGrade] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [showUploadForm, setShowUploadForm] = useState(false);

  const { data: books, isLoading } = trpc.books.getBooks.useQuery({
    grade: selectedGrade || undefined,
    subject: selectedSubject || undefined,
  });

  const canUpload = user?.role === "admin" || user?.role === "teacher";

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">الكتب التعليمية</h1>
        <p className="text-gray-600">مكتبة شاملة من الكتب والمراجع التعليمية</p>
      </div>

      {canUpload && (
        <div className="mb-6">
          <Button
            onClick={() => setShowUploadForm(!showUploadForm)}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Upload className="w-4 h-4 ml-2" />
            رفع كتاب جديد
          </Button>
        </div>
      )}

      {showUploadForm && canUpload && (
        <UploadBookForm onSuccess={() => setShowUploadForm(false)} />
      )}

      <div className="mb-6 flex gap-4 flex-wrap">
        <select
          value={selectedGrade}
          onChange={(e) => setSelectedGrade(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
        >
          <option value="">جميع الصفوف</option>
          <option value="الصف الأول">الصف الأول</option>
          <option value="الصف الثاني">الصف الثاني</option>
          <option value="الصف الثالث">الصف الثالث</option>
          <option value="الصف الرابع">الصف الرابع</option>
          <option value="الصف الخامس">الصف الخامس</option>
          <option value="الصف السادس">الصف السادس</option>
        </select>

        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
        >
          <option value="">جميع المواد</option>
          <option value="اللغة العربية">اللغة العربية</option>
          <option value="الرياضيات">الرياضيات</option>
          <option value="العلوم">العلوم</option>
          <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
          <option value="الدراسات الاجتماعية">الدراسات الاجتماعية</option>
        </select>
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          <p className="text-gray-600 mt-4">جاري التحميل...</p>
        </div>
      ) : books && books.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {books.map((book: any) => (
            <Card key={book.id} className="p-6 hover:shadow-lg transition-shadow flex flex-col">
              <div className="flex items-start justify-between mb-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-2 flex-1">{book.title}</h3>
              <p className="text-gray-600 text-sm mb-1">المادة: {book.subject}</p>
              <p className="text-gray-600 text-sm mb-4">الصف: {book.grade}</p>
              {book.description && (
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{book.description}</p>
              )}
              <a href={book.fileUrl} download className="mt-auto">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  <Download className="w-4 h-4 ml-2" />
                  تحميل الكتاب
                </Button>
              </a>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-8 text-center">
          <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">لا توجد كتب متاحة</p>
        </Card>
      )}
    </div>
  );
}

function UploadBookForm({ onSuccess }: any) {
  const [formData, setFormData] = useState({
    title: "",
    subject: "",
    grade: "",
    description: "",
  });
  const [file, setFile] = useState<File | null>(null);

  const uploadBook = trpc.books.uploadBook.useMutation({
    onSuccess: () => {
      setFormData({ title: "", subject: "", grade: "", description: "" });
      setFile(null);
      onSuccess();
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    // في التطبيق الفعلي، يجب رفع الملف إلى S3 أولاً والحصول على URL
    // للآن، سنستخدم URL مؤقت
    const fileUrl = URL.createObjectURL(file);
    const fileKey = `books/${Date.now()}-${file.name}`;

    uploadBook.mutate({
      title: formData.title,
      subject: formData.subject,
      grade: formData.grade,
      fileUrl: fileUrl,
      fileKey: fileKey,
      description: formData.description,
    });
  };

  return (
    <Card className="p-6 mb-8 bg-blue-50">
      <h2 className="text-xl font-bold text-gray-800 mb-4">رفع كتاب جديد</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          placeholder="عنوان الكتاب"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />

        <select
          value={formData.subject}
          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          required
        >
          <option value="">اختر المادة</option>
          <option value="اللغة العربية">اللغة العربية</option>
          <option value="الرياضيات">الرياضيات</option>
          <option value="العلوم">العلوم</option>
          <option value="اللغة الإنجليزية">اللغة الإنجليزية</option>
          <option value="الدراسات الاجتماعية">الدراسات الاجتماعية</option>
        </select>

        <select
          value={formData.grade}
          onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          required
        >
          <option value="">اختر الصف</option>
          <option value="الصف الأول">الصف الأول</option>
          <option value="الصف الثاني">الصف الثاني</option>
          <option value="الصف الثالث">الصف الثالث</option>
          <option value="الصف الرابع">الصف الرابع</option>
          <option value="الصف الخامس">الصف الخامس</option>
          <option value="الصف السادس">الصف السادس</option>
        </select>

        <div className="md:col-span-2">
          <input
            type="file"
            accept=".pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            required
          />
          <p className="text-sm text-gray-600 mt-1">ملفات PDF فقط</p>
        </div>

        <Input
          placeholder="الوصف (اختياري)"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="md:col-span-2"
        />

        <Button
          type="submit"
          disabled={uploadBook.isPending || !file}
          className="bg-green-600 hover:bg-green-700 text-white md:col-span-2"
        >
          {uploadBook.isPending ? "جاري الرفع..." : "رفع الكتاب"}
        </Button>
      </form>
    </Card>
  );
}

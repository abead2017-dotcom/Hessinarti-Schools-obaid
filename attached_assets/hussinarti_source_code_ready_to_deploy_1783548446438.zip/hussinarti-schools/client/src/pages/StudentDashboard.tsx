import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BookOpen, FileText, Calendar, Bell, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";

export default function StudentDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const { data: results } = trpc.results.getMyResults.useQuery();
  const { data: books } = trpc.books.getBooks.useQuery();
  const { data: events } = trpc.calendar.getEvents.useQuery();
  const { data: notifications } = trpc.notifications.getNotifications.useQuery();

  const recentResults = results?.slice(0, 3) || [];
  const recentBooks = books?.slice(0, 3) || [];
  const upcomingEvents = events?.slice(0, 3) || [];
  const unreadNotifications = notifications?.filter((n: any) => !n.isRead).slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-blue-600 to-blue-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">لوحة تحكم الطالب</h1>
              <p className="text-blue-100 mt-1">مرحباً {user?.name}</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="bg-blue-500 px-3 py-1 rounded-full text-sm">طالب</span>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="text-white border-white hover:bg-blue-700"
              >
                <LogOut className="w-4 h-4 ml-2" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-end gap-8 py-4">
            <Link href="/results">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">النتائج</a>
            </Link>
            <Link href="/books">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">الكتب</a>
            </Link>
            <Link href="/calendar">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">التقويم</a>
            </Link>
            <Link href="/notifications">
              <a className="text-gray-700 hover:text-blue-600 font-medium transition">الإشعارات</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="p-6 text-center">
            <div className="bg-blue-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-gray-600 text-sm">النتائج</p>
            <p className="text-3xl font-bold text-gray-800">{results?.length || 0}</p>
          </Card>

          <Card className="p-6 text-center">
            <div className="bg-green-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-gray-600 text-sm">الكتب المتاحة</p>
            <p className="text-3xl font-bold text-gray-800">{books?.length || 0}</p>
          </Card>

          <Card className="p-6 text-center">
            <div className="bg-purple-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
            <p className="text-gray-600 text-sm">الأحداث القادمة</p>
            <p className="text-3xl font-bold text-gray-800">{events?.length || 0}</p>
          </Card>

          <Card className="p-6 text-center">
            <div className="bg-red-100 p-4 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
              <Bell className="w-6 h-6 text-red-600" />
            </div>
            <p className="text-gray-600 text-sm">إشعارات جديدة</p>
            <p className="text-3xl font-bold text-gray-800">{unreadNotifications.length}</p>
          </Card>
        </div>

        {/* Recent Results */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">آخر النتائج</h2>
                <Link href="/results">
                  <a className="text-blue-600 hover:text-blue-700 font-medium">عرض الكل</a>
                </Link>
              </div>
              {recentResults.length > 0 ? (
                <div className="space-y-4">
                  {recentResults.map((result: any) => (
                    <div key={result.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-800">{result.subject}</p>
                        <p className="text-sm text-gray-600">{result.semester}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-blue-600">{result.score || result.grade}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600 text-center py-8">لا توجد نتائج متاحة حالياً</p>
              )}
            </Card>
          </div>

          {/* Notifications */}
          <Card className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">إشعارات جديدة</h2>
            {unreadNotifications.length > 0 ? (
              <div className="space-y-4">
                {unreadNotifications.map((notif: any) => (
                  <div key={notif.id} className="p-3 bg-blue-50 rounded-lg border-r-4 border-blue-600">
                    <p className="font-semibold text-gray-800 text-sm">{notif.title}</p>
                    <p className="text-xs text-gray-600 mt-1 line-clamp-2">{notif.message}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600 text-center py-8">لا توجد إشعارات جديدة</p>
            )}
            <Link href="/notifications">
              <a className="text-blue-600 hover:text-blue-700 font-medium text-sm mt-4 block">عرض جميع الإشعارات</a>
            </Link>
          </Card>
        </div>

        {/* Available Books & Events */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Books */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-800">الكتب المتاحة</h2>
              <Link href="/books">
                <a className="text-blue-600 hover:text-blue-700 font-medium">عرض الكل</a>
              </Link>
            </div>
            {recentBooks.length > 0 ? (
              <div className="space-y-3">
                {recentBooks.map((book: any) => (
                  <div key={book.id} className="p-3 bg-gray-50 rounded-lg">
                    <p className="font-semibold text-gray-800">{book.title}</p>
                    <p className="text-sm text-gray-600">{book.subject} - {book.grade}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600 text-center py-8">لا توجد كتب متاحة</p>
            )}
          </Card>

          {/* Upcoming Events */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-800">الأحداث القادمة</h2>
              <Link href="/calendar">
                <a className="text-blue-600 hover:text-blue-700 font-medium">عرض الكل</a>
              </Link>
            </div>
            {upcomingEvents.length > 0 ? (
              <div className="space-y-3">
                {upcomingEvents.map((event: any) => (
                  <div key={event.id} className="p-3 bg-gray-50 rounded-lg">
                    <p className="font-semibold text-gray-800">{event.title}</p>
                    <p className="text-sm text-gray-600">
                      {new Date(event.startDate).toLocaleDateString("ar-SA")}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600 text-center py-8">لا توجد أحداث قادمة</p>
            )}
          </Card>
        </div>
      </main>
    </div>
  );
}

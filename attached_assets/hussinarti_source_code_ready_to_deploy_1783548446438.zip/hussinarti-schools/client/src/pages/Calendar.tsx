import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Calendar as CalendarIcon, Plus, LogOut } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Calendar() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showAddForm, setShowAddForm] = useState(false);

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const { data: events } = trpc.calendar.getEvents.useQuery();

  const isAdmin = user?.role === "admin";

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-l from-purple-600 to-purple-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">التقويم الدراسي</h1>
              <p className="text-purple-100 mt-1">الفعاليات والمواعيد المهمة</p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="text-white border-white hover:bg-purple-700"
            >
              <LogOut className="w-4 h-4 ml-2" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-end gap-8 py-4">
            <Link href={user?.role === "student" ? "/dashboard/student" : user?.role === "teacher" ? "/dashboard/teacher" : "/dashboard/admin"}>
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">لوحة التحكم</a>
            </Link>
            <Link href="/results">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">النتائج</a>
            </Link>
            <Link href="/books">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">الكتب</a>
            </Link>
            <Link href="/notifications">
              <a className="text-gray-700 hover:text-purple-600 font-medium transition">الإشعارات</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
      {/* Add Event Button */}
      {isAdmin && (
        <div className="mb-8">
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Plus className="w-4 h-4 ml-2" />
            إضافة حدث جديد
          </Button>
        </div>
      )}

      {/* Add Event Form */}
      {showAddForm && isAdmin && (
        <Card className="p-6 mb-8">
          <AddEventForm onSuccess={() => setShowAddForm(false)} />
        </Card>
      )}

      {/* Events List */}
      <Card className="p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">الأحداث القادمة</h2>
        {events && events.length > 0 ? (
          <div className="space-y-4">
            {events.map((event: any) => (
            <div key={event.id} className="p-6 bg-gradient-to-l from-purple-50 to-blue-50 rounded-lg border-r-4 border-purple-600">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{event.title}</h3>
                  {event.description && (
                    <p className="text-gray-600 mb-3">{event.description}</p>
                  )}
                  <div className="flex gap-6 text-sm text-gray-600">
                    <div>
                      <span className="font-semibold">التاريخ:</span> {new Date(event.startDate).toLocaleDateString("ar-SA")}
                    </div>
                    {event.endDate && (
                      <div>
                        <span className="font-semibold">إلى:</span> {new Date(event.endDate).toLocaleDateString("ar-SA")}
                      </div>
                    )}
                    <div>
                      <span className="font-semibold">النوع:</span> {event.eventType}
                    </div>
                  </div>
                </div>
                <div className="bg-purple-100 p-3 rounded-lg ml-4">
                  <CalendarIcon className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <CalendarIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-lg">لا توجد أحداث مسجلة</p>
          </div>
        )}
      </Card>
      </main>
    </div>
  );
}

function AddEventForm({ onSuccess }: any) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startDate: "",
    endDate: "",
        eventType: "عام",
  });

  const addEvent = trpc.calendar.addEvent.useMutation({
    onSuccess: () => {
      setFormData({
        title: "",
        description: "",
        startDate: "",
        endDate: "",
        eventType: "عام",
      });
      onSuccess();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addEvent.mutate({
      title: formData.title,
      description: formData.description,
      startDate: new Date(formData.startDate),
      endDate: formData.endDate ? new Date(formData.endDate) : undefined,
      eventType: formData.eventType,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-xl font-bold text-gray-800 mb-4">إضافة حدث جديد</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          placeholder="عنوان الحدث"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />

        <select
          value={formData.eventType}
          onChange={(e) => setFormData({ ...formData, eventType: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
        >
          <option value="عام">عام</option>
          <option value="اختبار">اختبار</option>
          <option value="عطلة">عطلة</option>
          <option value="اجتماع">اجتماع</option>
          <option value="حفل">حفل</option>
        </select>

        <Input
          placeholder="تاريخ البداية"
          type="date"
          value={formData.startDate}
          onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
          required
        />

        <Input
          placeholder="تاريخ النهاية (اختياري)"
          type="date"
          value={formData.endDate}
          onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
        />

        <Input
          placeholder="الوصف (اختياري)"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="md:col-span-2"
        />
      </div>

      <Button
        type="submit"
        disabled={addEvent.isPending}
        className="w-full bg-purple-600 hover:bg-purple-700 text-white"
      >
        {addEvent.isPending ? "جاري الحفظ..." : "إضافة الحدث"}
      </Button>
    </form>
  );
}

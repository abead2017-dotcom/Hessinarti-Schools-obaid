import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { InsertUser, users, results, books, calendarEvents, notifications } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      const client = postgres(process.env.DATABASE_URL, { max: 1 });
      _db = drizzle(client);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "studentId"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onConflictDoUpdate({
      target: users.openId,
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// دوال النتائج الدراسية
export async function getStudentResults(studentId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(results).where(eq(results.studentId, studentId));
}

export async function getAllResults() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(results);
}

export async function addResult(result: typeof results.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(results).values(result);
  return inserted;
}

// دوال الكتب التعليمية
export async function getBooks(grade?: string, subject?: string) {
  const db = await getDb();
  if (!db) return [];
  
  if (grade && subject) {
    // BUG FIX: this branch previously only filtered by `grade` and silently
    // dropped the `subject` filter, so searching by grade+subject returned
    // books from the right grade but any subject.
    return await db.select().from(books)
      .where(and(eq(books.grade, grade), eq(books.subject, subject)))
      .orderBy(desc(books.createdAt));
  }
  if (grade) {
    return await db.select().from(books)
      .where(eq(books.grade, grade))
      .orderBy(desc(books.createdAt));
  }
  if (subject) {
    return await db.select().from(books)
      .where(eq(books.subject, subject))
      .orderBy(desc(books.createdAt));
  }
  
  return await db.select().from(books).orderBy(desc(books.createdAt));
}

export async function addBook(book: typeof books.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(books).values(book);
  return inserted;
}

// دوال التقويم الدراسي
export async function getCalendarEvents() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(calendarEvents).orderBy(calendarEvents.startDate);
}

export async function addCalendarEvent(event: typeof calendarEvents.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(calendarEvents).values(event);
  return inserted;
}

// دوال الإشعارات
export async function getNotifications(userId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(notifications).orderBy(desc(notifications.createdAt));
}

export async function addNotification(notification: typeof notifications.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const inserted = await db.insert(notifications).values(notification);
  return inserted;
}

import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;

// Centralized error-handling middleware.
// Every procedure (public/protected/admin) passes through this, so:
//  - Unexpected errors (DB failures, network calls, bugs) are logged server-side
//    with enough context to debug, but NEVER leak raw internals (stack traces,
//    SQL messages, file paths) to the client.
//  - Errors that were already deliberately thrown as TRPCError (FORBIDDEN,
//    UNAUTHORIZED, BAD_REQUEST, etc.) pass through unchanged, since those
//    messages were already written to be safe/user-facing.
const errorHandlingMiddleware = t.middleware(async ({ path, type, next }) => {
  const result = await next();

  if (!result.ok) {
    const { error } = result;

    if (error instanceof TRPCError && error.code !== "INTERNAL_SERVER_ERROR") {
      console.warn(`[tRPC] ${type} ${path} -> ${error.code}: ${error.message}`);
    } else {
      console.error(`[tRPC] ${type} ${path} failed:`, error.cause ?? error);

      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى لاحقاً.",
        cause: error,
      });
    }
  }

  return result;
});

export const publicProcedure = t.procedure.use(errorHandlingMiddleware);

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

// IMPORTANT: chain from `publicProcedure`, not `t.procedure`, so protected/admin
// procedures also get the centralized error handling above. The original code
// built these from `t.procedure` directly, which meant every protected and
// admin route (i.e. almost the whole app) skipped the error-handling
// middleware entirely.
export const protectedProcedure = publicProcedure.use(requireUser);

export const adminProcedure = publicProcedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== 'admin') {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);

import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb, getStudentResults, getAllResults, addResult, getBooks, addBook, getCalendarEvents, addCalendarEvent, getNotifications, addNotification } from "./db";
import { TRPCError } from "@trpc/server";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// إنشاء إجراء محمي للمدير فقط
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'يجب أن تكون مديراً للوصول إلى هذه الميزة' });
  }
  return next({ ctx });
});

// إنشاء إجراء محمي للمعلمين والمديرين
const teacherOrAdminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== 'admin' && ctx.user.role !== 'teacher') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'يجب أن تكون معلماً أو مديراً للوصول إلى هذه الميزة' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    updateUserRole: protectedProcedure.input(z.object({
      role: z.enum(['student', 'teacher', 'admin']),
    })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database not available' });
      
      await db.update(users)
        .set({ role: input.role })
        .where(eq(users.id, ctx.user.id));
      
      return { ...ctx.user, role: input.role };
    }),
  }),

  // نظام النتائج الدراسية
  results: router({
    // الطلاب يمكنهم عرض نتائجهم فقط
    getMyResults: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'student') {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'فقط الطلاب يمكنهم عرض نتائجهم' });
      }
      return await getStudentResults(ctx.user.id);
    }),

    // المدير يمكنه عرض جميع النتائج
    getAllResults: adminProcedure.query(async () => {
      return await getAllResults();
    }),

    // المدير يمكنه إضافة نتائج جديدة
    addResult: adminProcedure.input(z.object({
      studentId: z.number(),
      subject: z.string(),
      grade: z.string(),
      score: z.number().optional(),
      semester: z.string(),
      academicYear: z.string(),
    })).mutation(async ({ input }) => {
      return await addResult(input);
    }),
  }),

  // نظام الكتب التعليمية
  books: router({
    // الجميع يمكنهم عرض الكتب
    getBooks: publicProcedure.input(z.object({
      grade: z.string().optional(),
      subject: z.string().optional(),
    }).optional()).query(async ({ input }) => {
      return await getBooks(input?.grade, input?.subject);
    }),

    // المعلمون والمديرون يمكنهم رفع الكتب
    uploadBook: teacherOrAdminProcedure.input(z.object({
      title: z.string(),
      subject: z.string(),
      grade: z.string(),
      fileUrl: z.string(),
      fileKey: z.string(),
      description: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      return await addBook({
        ...input,
        uploadedBy: ctx.user.id,
      });
    }),
  }),

  // نظام التقويم الدراسي
  calendar: router({
    // الجميع يمكنهم عرض الأحداث
    getEvents: publicProcedure.query(async () => {
      return await getCalendarEvents();
    }),

    // المدير فقط يمكنه إضافة أحداث
    addEvent: adminProcedure.input(z.object({
      title: z.string(),
      description: z.string().optional(),
      startDate: z.date(),
      endDate: z.date().optional(),
      eventType: z.string(),
    })).mutation(async ({ input, ctx }) => {
      return await addCalendarEvent({
        ...input,
        createdBy: ctx.user.id,
      });
    }),
  }),

  // نظام الإشعارات
  notifications: router({
    // الجميع يمكنهم عرض الإشعارات
    getNotifications: protectedProcedure.query(async () => {
      return await getNotifications();
    }),

    // المدير فقط يمكنه إرسال إشعارات
    sendNotification: adminProcedure.input(z.object({
      title: z.string(),
      message: z.string(),
      recipientType: z.enum(['all', 'students', 'specific']),
      recipientIds: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      return await addNotification({
        ...input,
        sentBy: ctx.user.id,
      });
    }),
  }),
});

export type AppRouter = typeof appRouter;
